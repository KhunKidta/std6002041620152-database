<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model frontend\models\PropertyforrentSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="propertyforrent-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id') ?>

    <?= $form->field($model, 'property_no') ?>

    <?= $form->field($model, 'street') ?>

    <?= $form->field($model, 'city') ?>

    <?= $form->field($model, 'postcode') ?>

    <?php // echo $form->field($model, 'type') ?>

    <?php // echo $form->field($model, 'room') ?>

    <?php // echo $form->field($model, 'rent') ?>

    <?php // echo $form->field($model, 'owner_no') ?>

    <?php // echo $form->field($model, 'staff_no') ?>

    <?php // echo $form->field($model, 'branch_no') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-outline-secondary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
