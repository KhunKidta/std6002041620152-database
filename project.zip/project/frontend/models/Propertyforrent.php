<?php

namespace frontend\models;

class Propertyforrent extends \common\models\Propertyforrent{};

