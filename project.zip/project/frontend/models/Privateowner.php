<?php

namespace frontend\models;

class Privateowner extends \common\models\Privateowner{};

