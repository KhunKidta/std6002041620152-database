<?php

namespace frontend\models;

class Client extends \common\models\Client{};

