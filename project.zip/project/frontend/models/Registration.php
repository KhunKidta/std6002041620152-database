<?php

namespace frontend\models;

class Registration extends \common\models\Registration{};

