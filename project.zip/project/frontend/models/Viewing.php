<?php

namespace frontend\models;

class Viewing extends \common\models\Viewing{};

