<?php

namespace frontend\models;

class Staff extends \common\models\Staff{};

