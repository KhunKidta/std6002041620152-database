<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%privateowner}}`.
 */
class m190430_212912_create_privateowner_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%privateowner}}', [
            'id' => $this->primaryKey(),
            'owner_no' => $this->string(4),
            'first_name' => $this->string(300),
            'last_name' => $this->string(300),
            'address' => $this->string(300),
            'tel_no' => $this->string(13)
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%privateowner}}');
    }
}
