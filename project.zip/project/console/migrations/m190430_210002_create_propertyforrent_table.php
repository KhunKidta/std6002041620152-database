<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%propertyforrent}}`.
 */
class m190430_210002_create_propertyforrent_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%propertyforrent}}', [
            'id' => $this->primaryKey(),
            'property_no' => $this->string(4),
            'street' => $this->string(200),
            'city' => $this->string(150),
            'postcode' => $this->string(20),
            'type' => $this->string(50),
            'room' => $this->integer(),
            'rent' => $this->integer(),
            'owner_no' => $this->string(4),
            'staff_no' => $this->string(4),
            'branch_no' => $this->string(4)
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%propertyforrent}}');
    }
}
