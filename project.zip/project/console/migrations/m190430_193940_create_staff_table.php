<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%staff}}`.
 */
class m190430_193940_create_staff_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%staff}}', [
            'id' => $this->primaryKey(),
            'staff_no' => $this->string(4),
            'first_name' => $this->string(300),
            'last_name' => $this->string(300),
            'position' => $this->string(20),
            'sex' => $this->string(5),
            'date_of_birth' => $this->string(30),
            'salary' => $this->integer(),
            'branch_no' => $this->string(4),
            'pref_type' => $this->string(10),
            'max_rent' => $this->integer()
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%staff}}');
    }
}
