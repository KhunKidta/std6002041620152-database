<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "viewing".
 *
 * @property int $id
 * @property string $client_no
 * @property string $property_no
 * @property string $view_date
 * @property string $comment
 */
class Viewing extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'viewing';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['client_no', 'property_no'], 'string', 'max' => 4],
            [['view_date'], 'string', 'max' => 10],
            [['comment'], 'string', 'max' => 200],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'client_no' => 'Client No',
            'property_no' => 'Property No',
            'view_date' => 'View Date',
            'comment' => 'Comment',
        ];
    }
}
