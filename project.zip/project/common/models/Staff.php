<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "staff".
 *
 * @property int $id
 * @property string $staff_no
 * @property string $first_name
 * @property string $last_name
 * @property string $position
 * @property string $sex
 * @property string $date_of_birth
 * @property int $salary
 * @property string $branch_no
 * @property string $pref_type
 * @property int $max_rent
 */
class Staff extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'staff';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['salary', 'max_rent'], 'integer'],
            [['staff_no', 'branch_no'], 'string', 'max' => 4],
            [['first_name', 'last_name'], 'string', 'max' => 300],
            [['position'], 'string', 'max' => 20],
            [['sex'], 'string', 'max' => 5],
            [['date_of_birth'], 'string', 'max' => 30],
            [['pref_type'], 'string', 'max' => 10],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'staff_no' => 'Staff No',
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'position' => 'Position',
            'sex' => 'Sex',
            'date_of_birth' => 'Date Of Birth',
            'salary' => 'Salary',
            'branch_no' => 'Branch No',
            'pref_type' => 'Pref Type',
            'max_rent' => 'Max Rent',
        ];
    }
}
