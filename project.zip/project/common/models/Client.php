<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "client".
 *
 * @property int $id
 * @property string $client_no
 * @property string $first_name
 * @property string $last_name
 * @property string $tel_no
 * @property string $pref_type
 * @property int $max_rent
 */
class Client extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'client';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['max_rent'], 'integer'],
            [['client_no'], 'string', 'max' => 4],
            [['first_name', 'last_name'], 'string', 'max' => 300],
            [['tel_no'], 'string', 'max' => 13],
            [['pref_type'], 'string', 'max' => 10],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'client_no' => 'Client No',
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'tel_no' => 'Tel No',
            'pref_type' => 'Pref Type',
            'max_rent' => 'Max Rent',
        ];
    }
}
