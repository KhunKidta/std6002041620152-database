<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "registration".
 *
 * @property int $id
 * @property string $client_no
 * @property string $branch_no
 * @property string $staff_no
 * @property string $datejoined
 */
class Registration extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'registration';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['client_no', 'branch_no', 'staff_no'], 'string', 'max' => 4],
            [['datejoined'], 'string', 'max' => 10],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'client_no' => 'Client No',
            'branch_no' => 'Branch No',
            'staff_no' => 'Staff No',
            'datejoined' => 'Datejoined',
        ];
    }
}
