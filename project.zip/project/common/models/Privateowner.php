<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "privateowner".
 *
 * @property int $id
 * @property string $owner_no
 * @property string $first_name
 * @property string $last_name
 * @property string $address
 * @property string $tel_no
 */
class Privateowner extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'privateowner';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['owner_no'], 'string', 'max' => 4],
            [['first_name', 'last_name', 'address'], 'string', 'max' => 300],
            [['tel_no'], 'string', 'max' => 13],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'owner_no' => 'Owner No',
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'address' => 'Address',
            'tel_no' => 'Tel No',
        ];
    }
}
