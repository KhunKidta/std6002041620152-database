<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "propertyforrent".
 *
 * @property int $id
 * @property string $property_no
 * @property string $street
 * @property string $city
 * @property string $postcode
 * @property string $type
 * @property int $room
 * @property int $rent
 * @property string $owner_no
 * @property string $staff_no
 * @property string $branch_no
 */
class Propertyforrent extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'propertyforrent';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['room', 'rent'], 'integer'],
            [['property_no', 'owner_no', 'staff_no', 'branch_no'], 'string', 'max' => 4],
            [['street'], 'string', 'max' => 200],
            [['city'], 'string', 'max' => 150],
            [['postcode'], 'string', 'max' => 20],
            [['type'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'property_no' => 'Property No',
            'street' => 'Street',
            'city' => 'City',
            'postcode' => 'Postcode',
            'type' => 'Type',
            'room' => 'Room',
            'rent' => 'Rent',
            'owner_no' => 'Owner No',
            'staff_no' => 'Staff No',
            'branch_no' => 'Branch No',
        ];
    }
}
